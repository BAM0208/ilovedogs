
export default function Home() {
  return (
    <div>
      <h1>I Love Dogs</h1>
      <p>Welcome to our dog product affiliate store!</p>
    </div>
  );
}
